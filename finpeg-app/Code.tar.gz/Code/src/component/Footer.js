import React,{component} from 'react';

const Footer = ()=>{
  
    return (
    <div className = 'footer-main'>
         <i class="fas fa-home"></i>
         <i class="fas fa-rupee-sign"></i>
         <i class="fas fa-file-invoice"></i>
         <i class="fas fa-id-badge"></i>
    </div>
    )
}

export default Footer;